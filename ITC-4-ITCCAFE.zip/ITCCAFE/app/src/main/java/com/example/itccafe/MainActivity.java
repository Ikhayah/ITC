 package com.example.itccafe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

 public class MainActivity extends AppCompatActivity implements View.OnClickListener {

     int jumlahMakan = 0;
     int JumlahMinum = 0;
     int totalHarga = 0;
     final int HARGA_MAKAN = 80000;
     final int HARGA_MINUM = 10000;

    Button btnTambahMakan, btnKurangMakan, btnTambahMinum,btnKurangMinum, btnReset,btnBuy;
    TextView tvJumlahmakan, tvJumlahminum, tvHarga, tvPurchase;


     @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnTambahMakan = findViewById(R.id.btn_tambahmakan);
        btnKurangMakan = findViewById(R.id.btn_kurangmakan);
        btnTambahMinum = findViewById(R.id.btn_tambahminum);
        btnKurangMinum = findViewById(R.id.btn_kurangminum);
        btnReset = findViewById(R.id.btn_reset);
        btnBuy = findViewById(R.id.btn_buy);

         tvJumlahmakan = findViewById(R.id.tv_jumlahmakan);
         tvJumlahminum = findViewById(R.id.tv_jumlahminum);
         tvHarga = findViewById(R.id.tv_harga);
         tvPurchase = findViewById(R.id.tv_purchase);

         btnTambahMakan.setOnClickListener(this);
         btnKurangMakan.setOnClickListener(this);
         btnTambahMinum.setOnClickListener(this);
         btnKurangMinum.setOnClickListener(this);
         btnBuy.setOnClickListener(this);
         btnReset.setOnClickListener(this);


         tvPurchase.setText("");
    }

     @Override
     public void onClick(View v) {

         switch (v.getId()){
             case R.id.btn_tambahmakan :
                 tambahpesananan(R.id.btn_tambahmakan);
                 break;
             case R.id.btn_tambahminum :
                 tambahpesananan(R.id.btn_tambahminum);
                 break;
             case R.id.btn_kurangmakan :
                 kurangpesananan(R.id.btn_kurangmakan);
                 break;
             case R.id.btn_kurangminum :
                 kurangpesananan(R.id.btn_kurangminum);
                 break;
             case R.id.btn_buy :
                 tvPurchase.setText("Purchased");
                 break;
             case R.id.btn_reset :
                 reset();
                 break;
         }
     }

     void reset(){

         int jumlahMakan = 0;
         int JumlahMinum = 0;
         int totalHarga = 0;

         tvJumlahmakan.setText("0");
         tvJumlahminum.setText("0");
         tvHarga.setText("Rp.0");
         tvPurchase.setText("");


     }

     void tambahpesananan(int asal){
         if (asal == R.id.btn_tambahmakan )
         {
             if (jumlahMakan < 10) {
                 jumlahMakan++;
                 totalHarga = totalHarga+HARGA_MAKAN;
                 tvJumlahmakan.setText(""+jumlahMakan);
                 tvHarga.setText("Rp."+totalHarga);
             }
         }

         if (asal == R.id.btn_tambahminum )
         {
             if (JumlahMinum < 10) {
                 JumlahMinum++;
                 totalHarga = totalHarga+HARGA_MINUM;
                 tvJumlahminum.setText(""+JumlahMinum);
                 tvHarga.setText("Rp."+totalHarga);
             }
         }



     }


     void kurangpesananan(int asal){
         if (asal == R.id.btn_kurangmakan )
         {
             if (jumlahMakan > 0) {
                 jumlahMakan--;
                 totalHarga = totalHarga-HARGA_MAKAN;
                 tvJumlahmakan.setText(""+jumlahMakan);
                 tvHarga.setText("Rp."+totalHarga);
             }
         }

         if (asal == R.id.btn_kurangminum )
         {
             if (JumlahMinum > 0) {
                 JumlahMinum--;
                 totalHarga = totalHarga-HARGA_MINUM;
                 tvJumlahminum.setText(""+JumlahMinum);
                 tvHarga.setText("Rp."+totalHarga);
             }
         }



     }
 }
